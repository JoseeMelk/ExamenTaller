import { Controller, Get } from '@nestjs/common';
import { ItemService } from './item.service';

@Controller('item')
export class ItemController {
    constructor(private readonly item : ItemService){}

    @Get()
    getIng(): string[]{
        return this.item.getCivil();
    }
}
