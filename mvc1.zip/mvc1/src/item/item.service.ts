import { Injectable } from '@nestjs/common';

@Injectable()
export class ItemService {
    getSolar(): string {
        return 'Te amo callita';
    }

    getCivil() : string[]{
        const cadena : string[] = ['valeria', 'solar'];
        return cadena;
    }
}
