import { Controller, Get, Render } from '@nestjs/common';
import { AppService } from './app.service';
import { get } from 'http';

@Controller()
export class AppController {
  constructor(private readonly appService: AppService) {}

  @Get()
  getHello(): string {
    return this.appService.getHello();
  }

  @Get('html')
  getHtml(): string {
    let html : string = this.appService.getHtml();
    return html;
  }

  @Render('home/index')
  @Get('hbs')
  getHbs(){
    var message : string = this.appService.getHbsMessage();
    let html : string = this.appService.getHtml();

    return {message, html};
  }
}