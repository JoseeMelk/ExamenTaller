import { Injectable } from '@nestjs/common';
import * as fs from 'fs';
import * as path from 'path';

@Injectable()
export class AppService {
  getHello(): string {
    return 'Hello World!';
  }

  getHtml() : string{
    const projectDir = path.resolve(__dirname, '..');

    const content = fs.readFileSync(path.join(projectDir, 'views/index.html'), 'utf8');
    return content;
  }

  getHbsMessage(): string{
    return 'Hello Melk!';
  }
}
